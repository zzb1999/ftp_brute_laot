<?php

define('HDOM_TYPE_ELEMENT', 1);
define('HDOM_TYPE_COMMENT', 2);
define('HDOM_TYPE_TEXT', 3);
define('HDOM_TYPE_ENDTAG', 4);
define('HDOM_TYPE_ROOT', 5);
define('HDOM_TYPE_UNKNOWN', 6);
define('HDOM_QUOTE_DOUBLE', 0);
define('HDOM_QUOTE_SINGLE', 1);
define('HDOM_QUOTE_NO', 3);
define('HDOM_INFO_BEGIN', 0);
define('HDOM_INFO_END', 1);
define('HDOM_INFO_QUOTE', 2);
define('HDOM_INFO_SPACE', 3);
define('HDOM_INFO_TEXT', 4);
define('HDOM_INFO_INNER', 5);
define('HDOM_INFO_OUTER', 6);
define('HDOM_INFO_ENDSPACE', 7);
define('DEFAULT_TARGET_CHARSET', 'GB2312//IGNORE');
define('DEFAULT_BR_TEXT', "\r\n");
define('DEFAULT_SPAN_TEXT', ' ');
define('MAX_FILE_SIZE', 600000);
function file_get_html($_var_0, $_var_1 = false, $_var_2 = null, $_var_3 = -1, $_var_4 = -1, $_var_5 = true, $_var_6 = true, $_var_7 = DEFAULT_TARGET_CHARSET, $_var_8 = true, $_var_9 = DEFAULT_BR_TEXT, $_var_10 = DEFAULT_SPAN_TEXT)
{
	$_var_11 = new simple_html_dom(null, $_var_5, $_var_6, $_var_7, $_var_8, $_var_9, $_var_10);
	$_var_12 = file_get_contents($_var_0, $_var_1, $_var_2, $_var_3);
	if (empty($_var_12) || strlen($_var_12) > MAX_FILE_SIZE) {
		return false;
	}
	$_var_11->load($_var_12, $_var_5, $_var_8);
	return $_var_11;
}
function str_get_html($_var_13, $_var_5 = true, $_var_6 = true, $_var_7 = DEFAULT_TARGET_CHARSET, $_var_8 = true, $_var_9 = DEFAULT_BR_TEXT, $_var_10 = DEFAULT_SPAN_TEXT)
{
	$_var_11 = new simple_html_dom(null, $_var_5, $_var_6, $_var_7, $_var_8, $_var_9, $_var_10);
	if (empty($_var_13) || strlen($_var_13) > MAX_FILE_SIZE) {
		$_var_11->clear();
		return false;
	}
	$_var_11->load($_var_13, $_var_5, $_var_8);
	return $_var_11;
}
function dump_html_tree($_var_14, $_var_15 = true, $_var_16 = 0)
{
	$_var_14->dump($_var_14);
}
class simple_html_dom_node
{
	public $nodetype = HDOM_TYPE_TEXT;
	public $tag = 'text';
	public $attr = array();
	public $children = array();
	public $nodes = array();
	public $parent = null;
	public $_ = array();
	public $tag_start = 0;
	private $dom = null;
	function __construct($_var_11)
	{
		$this->dom = $_var_11;
		$_var_11->nodes[] = $this;
	}
	function __destruct()
	{
		$this->clear();
	}
	function __toString()
	{
		return $this->outertext();
	}
	function clear()
	{
		$this->dom = null;
		$this->nodes = null;
		$this->parent = null;
		$this->children = null;
	}
	function dump($_var_15 = true, $_var_16 = 0)
	{
		$_var_17 = str_repeat('    ', $_var_16);
		echo $_var_17 . $this->tag;
		if ($_var_15 && count($this->attr) > 0) {
			echo '(';
			foreach ($this->attr as $_var_18 => $_var_19) {
				echo "[{$_var_18}]=>\"" . $this->{$_var_18} . '", ';
			}
			echo ')';
		}
		echo "\n";
		if ($this->nodes) {
			foreach ($this->nodes as $_var_20) {
				$_var_20->dump($_var_15, $_var_16 + 1);
			}
		}
	}
	function dump_node($_var_21 = true)
	{
		$_var_22 = $this->tag;
		if (count($this->attr) > 0) {
			$_var_22 .= '(';
			foreach ($this->attr as $_var_18 => $_var_19) {
				$_var_22 .= "[{$_var_18}]=>\"" . $this->{$_var_18} . '", ';
			}
			$_var_22 .= ')';
		}
		if (count($this->_) > 0) {
			$_var_22 .= ' $_ (';
			foreach ($this->_ as $_var_18 => $_var_19) {
				if (is_array($_var_19)) {
					$_var_22 .= "[{$_var_18}]=>(";
					foreach ($_var_19 as $_var_23 => $_var_24) {
						$_var_22 .= "[{$_var_23}]=>\"" . $_var_24 . '", ';
					}
					$_var_22 .= ')';
				} else {
					$_var_22 .= "[{$_var_18}]=>\"" . $_var_19 . '", ';
				}
			}
			$_var_22 .= ')';
		}
		if (isset($this->text)) {
			$_var_22 .= ' text: (' . $this->text . ')';
		}
		$_var_22 .= ' HDOM_INNER_INFO: \'';
		if (isset($_var_14->_[HDOM_INFO_INNER])) {
			$_var_22 .= $_var_14->_[HDOM_INFO_INNER] . '\'';
		} else {
			$_var_22 .= ' NULL ';
		}
		$_var_22 .= ' children: ' . count($this->children);
		$_var_22 .= ' nodes: ' . count($this->nodes);
		$_var_22 .= ' tag_start: ' . $this->tag_start;
		$_var_22 .= "\n";
		if ($_var_21) {
			echo $_var_22;
			return;
		} else {
			return $_var_22;
		}
	}
	function parent($_var_25 = null)
	{
		if ($_var_25 !== null) {
			$this->parent = $_var_25;
			$this->parent->nodes[] = $this;
			$this->parent->children[] = $this;
		}
		return $this->parent;
	}
	function has_child()
	{
		return !empty($this->children);
	}
	function children($_var_26 = -1)
	{
		if ($_var_26 === -1) {
			return $this->children;
		}
		if (isset($this->children[$_var_26])) {
			return $this->children[$_var_26];
		}
		return null;
	}
	function first_child()
	{
		if (count($this->children) > 0) {
			return $this->children[0];
		}
		return null;
	}
	function last_child()
	{
		if (($_var_27 = count($this->children)) > 0) {
			return $this->children[$_var_27 - 1];
		}
		return null;
	}
	function next_sibling()
	{
		if ($this->parent === null) {
			return null;
		}
		$_var_26 = 0;
		$_var_27 = count($this->parent->children);
		while ($_var_26 < $_var_27 && $this !== $this->parent->children[$_var_26]) {
			++$_var_26;
		}
		if (++$_var_26 >= $_var_27) {
			return null;
		}
		return $this->parent->children[$_var_26];
	}
	function prev_sibling()
	{
		if ($this->parent === null) {
			return null;
		}
		$_var_26 = 0;
		$_var_27 = count($this->parent->children);
		while ($_var_26 < $_var_27 && $this !== $this->parent->children[$_var_26]) {
			++$_var_26;
		}
		if (--$_var_26 < 0) {
			return null;
		}
		return $this->parent->children[$_var_26];
	}
	function find_ancestor_tag($_var_28)
	{
		global $debugObject;
		if (is_object($debugObject)) {
			$debugObject->debugLogEntry(1);
		}
		$_var_29 = $this;
		while (!is_null($_var_29)) {
			if (is_object($debugObject)) {
				$debugObject->debugLog(2, 'Current tag is: ' . $_var_29->tag);
			}
			if ($_var_29->tag == $_var_28) {
				break;
			}
			$_var_29 = $_var_29->parent;
		}
		return $_var_29;
	}
	function innertext()
	{
		if (isset($this->_[HDOM_INFO_INNER])) {
			return $this->_[HDOM_INFO_INNER];
		}
		if (isset($this->_[HDOM_INFO_TEXT])) {
			return $this->dom->restore_noise($this->_[HDOM_INFO_TEXT]);
		}
		$_var_30 = '';
		foreach ($this->nodes as $_var_31) {
			$_var_30 .= $_var_31->outertext();
		}
		return $_var_30;
	}
	function outertext()
	{
		global $debugObject;
		if (is_object($debugObject)) {
			$_var_32 = '';
			if ($this->tag == 'text') {
				if (!empty($this->text)) {
					$_var_32 = ' with text: ' . $this->text;
				}
			}
			$debugObject->debugLog(1, 'Innertext of tag: ' . $this->tag . $_var_32);
		}
		if ($this->tag === 'root') {
			return $this->innertext();
		}
		if ($this->dom && $this->dom->callback !== null) {
			call_user_func_array($this->dom->callback, array($this));
		}
		if (isset($this->_[HDOM_INFO_OUTER])) {
			return $this->_[HDOM_INFO_OUTER];
		}
		if (isset($this->_[HDOM_INFO_TEXT])) {
			return $this->dom->restore_noise($this->_[HDOM_INFO_TEXT]);
		}
		if ($this->dom && $this->dom->nodes[$this->_[HDOM_INFO_BEGIN]]) {
			$_var_30 = $this->dom->nodes[$this->_[HDOM_INFO_BEGIN]]->makeup();
		} else {
			$_var_30 = "";
		}
		if (isset($this->_[HDOM_INFO_INNER])) {
			if ($this->tag != 'br') {
				$_var_30 .= $this->_[HDOM_INFO_INNER];
			}
		} else {
			if ($this->nodes) {
				foreach ($this->nodes as $_var_31) {
					$_var_30 .= $this->convert_text($_var_31->outertext());
				}
			}
		}
		if (isset($this->_[HDOM_INFO_END]) && $this->_[HDOM_INFO_END] != 0) {
			$_var_30 .= '</' . $this->tag . '>';
		}
		return $_var_30;
	}
	function text()
	{
		if (isset($this->_[HDOM_INFO_INNER])) {
			return $this->_[HDOM_INFO_INNER];
		}
		switch ($this->nodetype) {
			case HDOM_TYPE_TEXT:
				return $this->dom->restore_noise($this->_[HDOM_INFO_TEXT]);
			case HDOM_TYPE_COMMENT:
				return '';
			case HDOM_TYPE_UNKNOWN:
				return '';
		}
		if (strcasecmp($this->tag, 'script') === 0) {
			return '';
		}
		if (strcasecmp($this->tag, 'style') === 0) {
			return '';
		}
		$_var_30 = '';
		if (!is_null($this->nodes)) {
			foreach ($this->nodes as $_var_31) {
				$_var_30 .= $this->convert_text($_var_31->text());
			}
			if ($this->tag == 'span') {
				$_var_30 .= $this->dom->default_span_text;
			}
		}
		return $_var_30;
	}
	function xmltext()
	{
		$_var_30 = $this->innertext();
		$_var_30 = str_ireplace('<![CDATA[', '', $_var_30);
		$_var_30 = str_replace(']]>', '', $_var_30);
		return $_var_30;
	}
	function makeup()
	{
		if (isset($this->_[HDOM_INFO_TEXT])) {
			return $this->dom->restore_noise($this->_[HDOM_INFO_TEXT]);
		}
		$_var_30 = '<' . $this->tag;
		$_var_33 = -1;
		foreach ($this->attr as $_var_34 => $_var_35) {
			++$_var_33;
			if ($_var_35 === null || $_var_35 === false) {
				continue;
			}
			$_var_30 .= $this->_[HDOM_INFO_SPACE][$_var_33][0];
			if ($_var_35 === true) {
				$_var_30 .= $_var_34;
			} else {
				switch ($this->_[HDOM_INFO_QUOTE][$_var_33]) {
					case HDOM_QUOTE_DOUBLE:
						$_var_36 = '"';
						break;
					case HDOM_QUOTE_SINGLE:
						$_var_36 = '\'';
						break;
					default:
						$_var_36 = '';
				}
				$_var_30 .= $_var_34 . $this->_[HDOM_INFO_SPACE][$_var_33][1] . '=' . $this->_[HDOM_INFO_SPACE][$_var_33][2] . $_var_36 . $_var_35 . $_var_36;
			}
		}
		$_var_30 = $this->dom->restore_noise($_var_30);
		return $_var_30 . $this->_[HDOM_INFO_ENDSPACE] . '>';
	}
	function find($_var_37, $_var_26 = null, $_var_5 = false)
	{
		$_var_38 = $this->parse_selector($_var_37);
		if (($_var_27 = count($_var_38)) === 0) {
			return array();
		}
		$_var_39 = array();
		for ($_var_20 = 0; $_var_20 < $_var_27; ++$_var_20) {
			if (($_var_40 = count($_var_38[$_var_20])) === 0) {
				return array();
			}
			if (!isset($this->_[HDOM_INFO_BEGIN])) {
				return array();
			}
			$_var_41 = array($this->_[HDOM_INFO_BEGIN] => 1);
			for ($_var_42 = 0; $_var_42 < $_var_40; ++$_var_42) {
				$_var_30 = array();
				foreach ($_var_41 as $_var_18 => $_var_19) {
					$_var_31 = $_var_18 === -1 ? $this->dom->root : $this->dom->nodes[$_var_18];
					$_var_31->seek($_var_38[$_var_20][$_var_42], $_var_30, $_var_5);
				}
				$_var_41 = $_var_30;
			}
			foreach ($_var_41 as $_var_18 => $_var_19) {
				if (!isset($_var_39[$_var_18])) {
					$_var_39[$_var_18] = 1;
				}
			}
		}
		ksort($_var_39);
		$_var_43 = array();
		foreach ($_var_39 as $_var_18 => $_var_19) {
			$_var_43[] = $this->dom->nodes[$_var_18];
		}
		if (is_null($_var_26)) {
			return $_var_43;
		} else {
			if ($_var_26 < 0) {
				$_var_26 = count($_var_43) + $_var_26;
			}
		}
		return isset($_var_43[$_var_26]) ? $_var_43[$_var_26] : null;
	}
	protected function seek($_var_37, &$_var_30, $_var_5 = false)
	{
		global $debugObject;
		if (is_object($debugObject)) {
			$debugObject->debugLogEntry(1);
		}
		list($_var_28, $_var_34, $_var_35, $_var_44, $_var_45) = $_var_37;
		if ($_var_28 && $_var_34 && is_numeric($_var_34)) {
			$_var_27 = 0;
			foreach ($this->children as $_var_20) {
				if ($_var_28 === '*' || $_var_28 === $_var_20->tag) {
					if (++$_var_27 == $_var_34) {
						$_var_30[$_var_20->_[HDOM_INFO_BEGIN]] = 1;
						return;
					}
				}
			}
			return;
		}
		$_var_46 = !empty($this->_[HDOM_INFO_END]) ? $this->_[HDOM_INFO_END] : 0;
		if ($_var_46 == 0) {
			$_var_25 = $this->parent;
			while (!isset($_var_25->_[HDOM_INFO_END]) && $_var_25 !== null) {
				$_var_46 -= 1;
				$_var_25 = $_var_25->parent;
			}
			$_var_46 += $_var_25->_[HDOM_INFO_END];
		}
		for ($_var_33 = $this->_[HDOM_INFO_BEGIN] + 1; $_var_33 < $_var_46; ++$_var_33) {
			$_var_14 = $this->dom->nodes[$_var_33];
			$_var_47 = true;
			if ($_var_28 === '*' && !$_var_34) {
				if (in_array($_var_14, $this->children, true)) {
					$_var_30[$_var_33] = 1;
				}
				continue;
			}
			if ($_var_28 && $_var_28 != $_var_14->tag && $_var_28 !== '*') {
				$_var_47 = false;
			}
			if ($_var_47 && $_var_34) {
				if ($_var_45) {
					if (isset($_var_14->attr[$_var_34])) {
						$_var_47 = false;
					}
				} else {
					if ($_var_34 != 'plaintext' && !isset($_var_14->attr[$_var_34])) {
						$_var_47 = false;
					}
				}
			}
			if ($_var_47 && $_var_34 && $_var_35 && $_var_35 !== '*') {
				if ($_var_34 == 'plaintext') {
					$_var_48 = $_var_14->text();
				} else {
					$_var_48 = $_var_14->attr[$_var_34];
				}
				if (is_object($debugObject)) {
					$debugObject->debugLog(2, 'testing node: ' . $_var_14->tag . ' for attribute: ' . $_var_34 . $_var_44 . $_var_35 . ' where nodes value is: ' . $_var_48);
				}
				if ($_var_5) {
					$_var_49 = $this->match($_var_44, strtolower($_var_35), strtolower($_var_48));
				} else {
					$_var_49 = $this->match($_var_44, $_var_35, $_var_48);
				}
				if (is_object($debugObject)) {
					$debugObject->debugLog(2, 'after match: ' . ($_var_49 ? 'true' : 'false'));
				}
				if (!$_var_49 && strcasecmp($_var_34, 'class') === 0) {
					foreach (explode(' ', $_var_14->attr[$_var_34]) as $_var_18) {
						if (!empty($_var_18)) {
							if ($_var_5) {
								$_var_49 = $this->match($_var_44, strtolower($_var_35), strtolower($_var_18));
							} else {
								$_var_49 = $this->match($_var_44, $_var_35, $_var_18);
							}
							if ($_var_49) {
								break;
							}
						}
					}
				}
				if (!$_var_49) {
					$_var_47 = false;
				}
			}
			if ($_var_47) {
				$_var_30[$_var_33] = 1;
			}
			unset($_var_14);
		}
		if (is_object($debugObject)) {
			$debugObject->debugLog(1, 'EXIT - ret: ', $_var_30);
		}
	}
	protected function match($_var_44, $_var_50, $_var_51)
	{
		global $debugObject;
		if (is_object($debugObject)) {
			$debugObject->debugLogEntry(1);
		}
		switch ($_var_44) {
			case '=':
				return $_var_51 === $_var_50;
			case '!=':
				return $_var_51 !== $_var_50;
			case '^=':
				return preg_match('/^' . preg_quote($_var_50, '/') . '/', $_var_51);
			case '$=':
				return preg_match('/' . preg_quote($_var_50, '/') . '$/', $_var_51);
			case '*=':
				if ($_var_50[0] == '/') {
					return preg_match($_var_50, $_var_51);
				}
				return preg_match('/' . $_var_50 . '/i', $_var_51);
		}
		return false;
	}
	protected function parse_selector($_var_52)
	{
		global $debugObject;
		if (is_object($debugObject)) {
			$debugObject->debugLogEntry(1);
		}
		$_var_50 = '/([\\w-:\\*]*)(?:\\#([\\w-]+)|\\.([\\w-]+))?(?:\\[@?(!?[\\w-:]+)(?:([!*^$]?=)["\']?(.*?)["\']?)?\\])?([\\/, ]+)/is';
		preg_match_all($_var_50, trim($_var_52) . ' ', $_var_53, PREG_SET_ORDER);
		if (is_object($debugObject)) {
			$debugObject->debugLog(2, 'Matches Array: ', $_var_53);
		}
		$_var_38 = array();
		$_var_54 = array();
		foreach ($_var_53 as $_var_55) {
			$_var_55[0] = trim($_var_55[0]);
			if ($_var_55[0] === '' || $_var_55[0] === '/' || $_var_55[0] === '//') {
				continue;
			}
			if ($_var_55[1] === 'tbody') {
				continue;
			}
			list($_var_28, $_var_34, $_var_35, $_var_44, $_var_45) = array($_var_55[1], null, null, '=', false);
			if (!empty($_var_55[2])) {
				$_var_34 = 'id';
				$_var_35 = $_var_55[2];
			}
			if (!empty($_var_55[3])) {
				$_var_34 = 'class';
				$_var_35 = $_var_55[3];
			}
			if (!empty($_var_55[4])) {
				$_var_34 = $_var_55[4];
			}
			if (!empty($_var_55[5])) {
				$_var_44 = $_var_55[5];
			}
			if (!empty($_var_55[6])) {
				$_var_35 = $_var_55[6];
			}
			if ($this->dom->lowercase) {
				$_var_28 = strtolower($_var_28);
				$_var_34 = strtolower($_var_34);
			}
			if (isset($_var_34[0]) && $_var_34[0] === '!') {
				$_var_34 = substr($_var_34, 1);
				$_var_45 = true;
			}
			$_var_54[] = array($_var_28, $_var_34, $_var_35, $_var_44, $_var_45);
			if (trim($_var_55[7]) === ',') {
				$_var_38[] = $_var_54;
				$_var_54 = array();
			}
		}
		if (count($_var_54) > 0) {
			$_var_38[] = $_var_54;
		}
		return $_var_38;
	}
	function __get($_var_56)
	{
		if (isset($this->attr[$_var_56])) {
			return $this->convert_text($this->attr[$_var_56]);
		}
		switch ($_var_56) {
			case 'outertext':
				return $this->outertext();
			case 'innertext':
				return $this->innertext();
			case 'plaintext':
				return $this->text();
			case 'xmltext':
				return $this->xmltext();
			default:
				return array_key_exists($_var_56, $this->attr);
		}
	}
	function __set($_var_56, $_var_51)
	{
		switch ($_var_56) {
			case 'outertext':
				return $this->_[HDOM_INFO_OUTER] = $_var_51;
			case 'innertext':
				if (isset($this->_[HDOM_INFO_TEXT])) {
					return $this->_[HDOM_INFO_TEXT] = $_var_51;
				}
				return $this->_[HDOM_INFO_INNER] = $_var_51;
		}
		if (!isset($this->attr[$_var_56])) {
			$this->_[HDOM_INFO_SPACE][] = array(' ', '', '');
			$this->_[HDOM_INFO_QUOTE][] = HDOM_QUOTE_DOUBLE;
		}
		$this->attr[$_var_56] = $_var_51;
	}
	function __isset($_var_56)
	{
		switch ($_var_56) {
			case 'outertext':
				return true;
			case 'innertext':
				return true;
			case 'plaintext':
				return true;
		}
		return array_key_exists($_var_56, $this->attr) ? true : isset($this->attr[$_var_56]);
	}
	function __unset($_var_56)
	{
		if (isset($this->attr[$_var_56])) {
			unset($this->attr[$_var_56]);
		}
	}
	function convert_text($_var_32)
	{
		global $debugObject;
		if (is_object($debugObject)) {
			$debugObject->debugLogEntry(1);
		}
		$_var_57 = $_var_32;
		$_var_58 = "";
		$_var_59 = "";
		if ($this->dom) {
			$_var_58 = strtoupper($this->dom->_charset);
			$_var_59 = strtoupper($this->dom->_target_charset);
		}
		if (is_object($debugObject)) {
			$debugObject->debugLog(3, 'source charset: ' . $_var_58 . ' target charaset: ' . $_var_59);
		}
		if (!empty($_var_58) && !empty($_var_59) && strcasecmp($_var_58, $_var_59) != 0) {
			if (strcasecmp($_var_59, 'UTF-8') == 0 && $this->is_utf8($_var_32)) {
				$_var_57 = $_var_32;
			} else {
				$_var_57 = iconv($_var_58, $_var_59, $_var_32);
			}
		}
		if ($_var_59 == 'UTF-8') {
			if (substr($_var_57, 0, 3) == "\xef\xbb\xbf") {
				$_var_57 = substr($_var_57, 3);
			}
			if (substr($_var_57, -3) == "\xef\xbb\xbf") {
				$_var_57 = substr($_var_57, 0, -3);
			}
		}
		return $_var_57;
	}
	static function is_utf8($_var_13)
	{
		$_var_20 = 0;
		$_var_60 = 0;
		$_var_61 = 0;
		$_var_62 = strlen($_var_13);
		for ($_var_33 = 0; $_var_33 < $_var_62; $_var_33++) {
			$_var_20 = ord($_var_13[$_var_33]);
			if ($_var_20 > 128) {
				if ($_var_20 >= 254) {
					return false;
				} elseif ($_var_20 >= 252) {
					$_var_61 = 6;
				} elseif ($_var_20 >= 248) {
					$_var_61 = 5;
				} elseif ($_var_20 >= 240) {
					$_var_61 = 4;
				} elseif ($_var_20 >= 224) {
					$_var_61 = 3;
				} elseif ($_var_20 >= 192) {
					$_var_61 = 2;
				} else {
					return false;
				}
				if ($_var_33 + $_var_61 > $_var_62) {
					return false;
				}
				while ($_var_61 > 1) {
					$_var_33++;
					$_var_60 = ord($_var_13[$_var_33]);
					if ($_var_60 < 128 || $_var_60 > 191) {
						return false;
					}
					$_var_61--;
				}
			}
		}
		return true;
	}
	function get_display_size()
	{
		global $debugObject;
		$_var_63 = -1;
		$_var_64 = -1;
		if ($this->tag !== 'img') {
			return false;
		}
		if (isset($this->attr['width'])) {
			$_var_63 = $this->attr['width'];
		}
		if (isset($this->attr['height'])) {
			$_var_64 = $this->attr['height'];
		}
		if (isset($this->attr['style'])) {
			$_var_65 = array();
			preg_match_all('/([\\w-]+)\\s*:\\s*([^;]+)\\s*;?/', $this->attr['style'], $_var_53, PREG_SET_ORDER);
			foreach ($_var_53 as $_var_66) {
				$_var_65[$_var_66[1]] = $_var_66[2];
			}
			if (isset($_var_65['width']) && $_var_63 == -1) {
				if (strtolower(substr($_var_65['width'], -2)) == 'px') {
					$_var_67 = substr($_var_65['width'], 0, -2);
					if (filter_var($_var_67, FILTER_VALIDATE_INT)) {
						$_var_63 = $_var_67;
					}
				}
			}
			if (isset($_var_65['height']) && $_var_64 == -1) {
				if (strtolower(substr($_var_65['height'], -2)) == 'px') {
					$_var_68 = substr($_var_65['height'], 0, -2);
					if (filter_var($_var_68, FILTER_VALIDATE_INT)) {
						$_var_64 = $_var_68;
					}
				}
			}
		}
		$_var_54 = array('height' => $_var_64, 'width' => $_var_63);
		return $_var_54;
	}
	function getAllAttributes()
	{
		return $this->attr;
	}
	function getAttribute($_var_56)
	{
		return $this->__get($_var_56);
	}
	function setAttribute($_var_56, $_var_51)
	{
		$this->__set($_var_56, $_var_51);
	}
	function hasAttribute($_var_56)
	{
		return $this->__isset($_var_56);
	}
	function removeAttribute($_var_56)
	{
		$this->__set($_var_56, null);
	}
	function getElementById($_var_69)
	{
		return $this->find("#{$_var_69}", 0);
	}
	function getElementsById($_var_69, $_var_26 = null)
	{
		return $this->find("#{$_var_69}", $_var_26);
	}
	function getElementByTagName($_var_56)
	{
		return $this->find($_var_56, 0);
	}
	function getElementsByTagName($_var_56, $_var_26 = null)
	{
		return $this->find($_var_56, $_var_26);
	}
	function parentNode()
	{
		return $this->parent();
	}
	function childNodes($_var_26 = -1)
	{
		return $this->children($_var_26);
	}
	function firstChild()
	{
		return $this->first_child();
	}
	function lastChild()
	{
		return $this->last_child();
	}
	function nextSibling()
	{
		return $this->next_sibling();
	}
	function previousSibling()
	{
		return $this->prev_sibling();
	}
	function hasChildNodes()
	{
		return $this->has_child();
	}
	function nodeName()
	{
		return $this->tag;
	}
	function appendChild($_var_14)
	{
		$_var_14->parent($this);
		return $_var_14;
	}
}
class simple_html_dom
{
	public $root = null;
	public $nodes = array();
	public $callback = null;
	public $lowercase = false;
	public $original_size;
	public $size;
	protected $pos;
	protected $doc;
	protected $char;
	protected $cursor;
	protected $parent;
	protected $noise = array();
	protected $token_blank = " \t\r\n";
	protected $token_equal = ' =/>';
	protected $token_slash = " />\r\n\t";
	protected $token_attr = ' >';
	public $_charset = '';
	public $_target_charset = '';
	protected $default_br_text = "";
	public $default_span_text = "";
	protected $self_closing_tags = array('img' => 1, 'br' => 1, 'input' => 1, 'meta' => 1, 'link' => 1, 'hr' => 1, 'base' => 1, 'embed' => 1, 'spacer' => 1);
	protected $block_tags = array('root' => 1, 'body' => 1, 'form' => 1, 'div' => 1, 'span' => 1, 'table' => 1);
	protected $optional_closing_tags = array('tr' => array('tr' => 1, 'td' => 1, 'th' => 1), 'th' => array('th' => 1), 'td' => array('td' => 1), 'li' => array('li' => 1), 'dt' => array('dt' => 1, 'dd' => 1), 'dd' => array('dd' => 1, 'dt' => 1), 'dl' => array('dd' => 1, 'dt' => 1), 'p' => array('p' => 1), 'nobr' => array('nobr' => 1), 'b' => array('b' => 1), 'option' => array('option' => 1));
	function __construct($_var_13 = null, $_var_5 = true, $_var_6 = true, $_var_7 = DEFAULT_TARGET_CHARSET, $_var_8 = true, $_var_9 = DEFAULT_BR_TEXT, $_var_10 = DEFAULT_SPAN_TEXT)
	{
		if ($_var_13) {
			if (preg_match('/^http:\\/\\//i', $_var_13) || is_file($_var_13)) {
				$this->load_file($_var_13);
			} else {
				$this->load($_var_13, $_var_5, $_var_8, $_var_9, $_var_10);
			}
		}
		if (!$_var_6) {
			$this->optional_closing_array = array();
		}
		$this->_target_charset = $_var_7;
	}
	function __destruct()
	{
		$this->clear();
	}
	function load($_var_13, $_var_5 = true, $_var_8 = true, $_var_9 = DEFAULT_BR_TEXT, $_var_10 = DEFAULT_SPAN_TEXT)
	{
		global $debugObject;
		$this->prepare($_var_13, $_var_5, $_var_8, $_var_9, $_var_10);
		$this->remove_noise('\'<!--(.*?)-->\'is');
		$this->remove_noise('\'<!\\[CDATA\\[(.*?)\\]\\]>\'is', true);
		$this->remove_noise('\'<\\s*script[^>]*[^/]>(.*?)<\\s*/\\s*script\\s*>\'is');
		$this->remove_noise('\'<\\s*script\\s*>(.*?)<\\s*/\\s*script\\s*>\'is');
		$this->remove_noise('\'<\\s*style[^>]*[^/]>(.*?)<\\s*/\\s*style\\s*>\'is');
		$this->remove_noise('\'<\\s*style\\s*>(.*?)<\\s*/\\s*style\\s*>\'is');
		$this->remove_noise('\'<\\s*(?:code)[^>]*>(.*?)<\\s*/\\s*(?:code)\\s*>\'is');
		$this->remove_noise('\'(<\\?)(.*?)(\\?>)\'s', true);
		$this->remove_noise('\'(\\{\\w)(.*?)(\\})\'s', true);
		while ($this->parse()) {
		}
		$this->root->_[HDOM_INFO_END] = $this->cursor;
		$this->parse_charset();
		return $this;
	}
	function load_file()
	{
		$_var_70 = func_get_args();
		$this->load(call_user_func_array('file_get_contents', $_var_70), true);
		if (($_var_71 = error_get_last()) !== null) {
			$this->clear();
			return false;
		}
	}
	function set_callback($_var_72)
	{
		$this->callback = $_var_72;
	}
	function remove_callback()
	{
		$this->callback = null;
	}
	function save($_var_73 = '')
	{
		$_var_30 = $this->root->innertext();
		if ($_var_73 !== '') {
			file_put_contents($_var_73, $_var_30, LOCK_EX);
		}
		return $_var_30;
	}
	function find($_var_37, $_var_26 = null, $_var_5 = false)
	{
		return $this->root->find($_var_37, $_var_26, $_var_5);
	}
	function clear()
	{
		foreach ($this->nodes as $_var_31) {
			$_var_31->clear();
			$_var_31 = null;
		}
		if (isset($this->children)) {
			foreach ($this->children as $_var_31) {
				$_var_31->clear();
				$_var_31 = null;
			}
		}
		if (isset($this->parent)) {
			$this->parent->clear();
			unset($this->parent);
		}
		if (isset($this->root)) {
			$this->root->clear();
			unset($this->root);
		}
		unset($this->doc);
		unset($this->noise);
	}
	function dump($_var_15 = true)
	{
		$this->root->dump($_var_15);
	}
	protected function prepare($_var_13, $_var_5 = true, $_var_8 = true, $_var_9 = DEFAULT_BR_TEXT, $_var_10 = DEFAULT_SPAN_TEXT)
	{
		$this->clear();
		$this->size = strlen($_var_13);
		$this->original_size = $this->size;
		if ($_var_8) {
			$_var_13 = str_replace("\r", ' ', $_var_13);
			$_var_13 = str_replace("\n", ' ', $_var_13);
			$this->size = strlen($_var_13);
		}
		$this->doc = $_var_13;
		$this->pos = 0;
		$this->cursor = 1;
		$this->noise = array();
		$this->nodes = array();
		$this->lowercase = $_var_5;
		$this->default_br_text = $_var_9;
		$this->default_span_text = $_var_10;
		$this->root = new simple_html_dom_node($this);
		$this->root->tag = 'root';
		$this->root->_[HDOM_INFO_BEGIN] = -1;
		$this->root->nodetype = HDOM_TYPE_ROOT;
		$this->parent = $this->root;
		if ($this->size > 0) {
			$this->char = $this->doc[0];
		}
	}
	protected function parse()
	{
		if (($_var_74 = $this->copy_until_char('<')) === '') {
			return $this->read_tag();
		}
		$_var_14 = new simple_html_dom_node($this);
		++$this->cursor;
		$_var_14->_[HDOM_INFO_TEXT] = $_var_74;
		$this->link_nodes($_var_14, false);
		return true;
	}
	protected function parse_charset()
	{
		global $debugObject;
		$_var_75 = null;
		if (function_exists('get_last_retrieve_url_contents_content_type')) {
			$_var_76 = get_last_retrieve_url_contents_content_type();
			$_var_77 = preg_match('/charset=(.+)/', $_var_76, $_var_53);
			if ($_var_77) {
				$_var_75 = $_var_53[1];
				if (is_object($debugObject)) {
					$debugObject->debugLog(2, 'header content-type found charset of: ' . $_var_75);
				}
			}
		}
		if (empty($_var_75)) {
			$_var_78 = $this->root->find('meta[http-equiv=Content-Type]', 0);
			if (!empty($_var_78)) {
				$_var_79 = $_var_78->content;
				if (is_object($debugObject)) {
					$debugObject->debugLog(2, 'meta content-type tag found' . $_var_79);
				}
				if (!empty($_var_79)) {
					$_var_77 = preg_match('/charset=(.+)/', $_var_79, $_var_53);
					if ($_var_77) {
						$_var_75 = $_var_53[1];
					} else {
						if (is_object($debugObject)) {
							$debugObject->debugLog(2, 'meta content-type tag couldn\'t be parsed. using iso-8859 default.');
						}
						$_var_75 = 'ISO-8859-1';
					}
				}
			}
		}
		if (empty($_var_75)) {
			$_var_75 = mb_detect_encoding($this->root->plaintext . 'ascii', $_var_80 = array('UTF-8', 'CP1252'));
			if (is_object($debugObject)) {
				$debugObject->debugLog(2, 'mb_detect found: ' . $_var_75);
			}
			if ($_var_75 === false) {
				if (is_object($debugObject)) {
					$debugObject->debugLog(2, 'since mb_detect failed - using default of utf-8');
				}
				$_var_75 = 'UTF-8';
			}
		}
		if (strtolower($_var_75) == strtolower('ISO-8859-1') || strtolower($_var_75) == strtolower('Latin1') || strtolower($_var_75) == strtolower('Latin-1')) {
			if (is_object($debugObject)) {
				$debugObject->debugLog(2, 'replacing ' . $_var_75 . ' with CP1252 as its a superset');
			}
			$_var_75 = 'CP1252';
		}
		if (is_object($debugObject)) {
			$debugObject->debugLog(1, 'EXIT - ' . $_var_75);
		}
		return $this->_charset = $_var_75;
	}
	protected function read_tag()
	{
		if ($this->char !== '<') {
			$this->root->_[HDOM_INFO_END] = $this->cursor;
			return false;
		}
		$_var_81 = $this->pos;
		$this->char = ++$this->pos < $this->size ? $this->doc[$this->pos] : null;
		if ($this->char === '/') {
			$this->char = ++$this->pos < $this->size ? $this->doc[$this->pos] : null;
			$this->skip($this->token_blank);
			$_var_28 = $this->copy_until_char('>');
			if (($_var_82 = strpos($_var_28, ' ')) !== false) {
				$_var_28 = substr($_var_28, 0, $_var_82);
			}
			$_var_83 = strtolower($this->parent->tag);
			$_var_84 = strtolower($_var_28);
			if ($_var_83 !== $_var_84) {
				if (isset($this->optional_closing_tags[$_var_83]) && isset($this->block_tags[$_var_84])) {
					$this->parent->_[HDOM_INFO_END] = 0;
					$_var_85 = $this->parent;
					while ($this->parent->parent && strtolower($this->parent->tag) !== $_var_84) {
						$this->parent = $this->parent->parent;
					}
					if (strtolower($this->parent->tag) !== $_var_84) {
						$this->parent = $_var_85;
						if ($this->parent->parent) {
							$this->parent = $this->parent->parent;
						}
						$this->parent->_[HDOM_INFO_END] = $this->cursor;
						return $this->as_text_node($_var_28);
					}
				} else {
					if ($this->parent->parent && isset($this->block_tags[$_var_84])) {
						$this->parent->_[HDOM_INFO_END] = 0;
						$_var_85 = $this->parent;
						while ($this->parent->parent && strtolower($this->parent->tag) !== $_var_84) {
							$this->parent = $this->parent->parent;
						}
						if (strtolower($this->parent->tag) !== $_var_84) {
							$this->parent = $_var_85;
							$this->parent->_[HDOM_INFO_END] = $this->cursor;
							return $this->as_text_node($_var_28);
						}
					} else {
						if ($this->parent->parent && strtolower($this->parent->parent->tag) === $_var_84) {
							$this->parent->_[HDOM_INFO_END] = 0;
							$this->parent = $this->parent->parent;
						} else {
							return $this->as_text_node($_var_28);
						}
					}
				}
			}
			$this->parent->_[HDOM_INFO_END] = $this->cursor;
			if ($this->parent->parent) {
				$this->parent = $this->parent->parent;
			}
			$this->char = ++$this->pos < $this->size ? $this->doc[$this->pos] : null;
			return true;
		}
		$_var_14 = new simple_html_dom_node($this);
		$_var_14->_[HDOM_INFO_BEGIN] = $this->cursor;
		++$this->cursor;
		$_var_28 = $this->copy_until($this->token_slash);
		$_var_14->tag_start = $_var_81;
		if (isset($_var_28[0]) && $_var_28[0] === '!') {
			$_var_14->_[HDOM_INFO_TEXT] = '<' . $_var_28 . $this->copy_until_char('>');
			if (isset($_var_28[2]) && $_var_28[1] === '-' && $_var_28[2] === '-') {
				$_var_14->nodetype = HDOM_TYPE_COMMENT;
				$_var_14->tag = 'comment';
			} else {
				$_var_14->nodetype = HDOM_TYPE_UNKNOWN;
				$_var_14->tag = 'unknown';
			}
			if ($this->char === '>') {
				$_var_14->_[HDOM_INFO_TEXT] .= '>';
			}
			$this->link_nodes($_var_14, true);
			$this->char = ++$this->pos < $this->size ? $this->doc[$this->pos] : null;
			return true;
		}
		if ($_var_82 = strpos($_var_28, '<') !== false) {
			$_var_28 = '<' . substr($_var_28, 0, -1);
			$_var_14->_[HDOM_INFO_TEXT] = $_var_28;
			$this->link_nodes($_var_14, false);
			$this->char = $this->doc[--$this->pos];
			return true;
		}
		if (!preg_match('/^[\\w-:]+$/', $_var_28)) {
			$_var_14->_[HDOM_INFO_TEXT] = '<' . $_var_28 . $this->copy_until('<>');
			if ($this->char === '<') {
				$this->link_nodes($_var_14, false);
				return true;
			}
			if ($this->char === '>') {
				$_var_14->_[HDOM_INFO_TEXT] .= '>';
			}
			$this->link_nodes($_var_14, false);
			$this->char = ++$this->pos < $this->size ? $this->doc[$this->pos] : null;
			return true;
		}
		$_var_14->nodetype = HDOM_TYPE_ELEMENT;
		$_var_84 = strtolower($_var_28);
		$_var_14->tag = $this->lowercase ? $_var_84 : $_var_28;
		if (isset($this->optional_closing_tags[$_var_84])) {
			while (isset($this->optional_closing_tags[$_var_84][strtolower($this->parent->tag)])) {
				$this->parent->_[HDOM_INFO_END] = 0;
				$this->parent = $this->parent->parent;
			}
			$_var_14->parent = $this->parent;
		}
		$_var_86 = 0;
		$_var_87 = array($this->copy_skip($this->token_blank), '', '');
		do {
			if ($this->char !== null && $_var_87[0] === '') {
				break;
			}
			$_var_56 = $this->copy_until($this->token_equal);
			if ($_var_86 === $this->pos) {
				$this->char = ++$this->pos < $this->size ? $this->doc[$this->pos] : null;
				continue;
			}
			$_var_86 = $this->pos;
			if ($this->pos >= $this->size - 1 && $this->char !== '>') {
				$_var_14->nodetype = HDOM_TYPE_TEXT;
				$_var_14->_[HDOM_INFO_END] = 0;
				$_var_14->_[HDOM_INFO_TEXT] = '<' . $_var_28 . $_var_87[0] . $_var_56;
				$_var_14->tag = 'text';
				$this->link_nodes($_var_14, false);
				return true;
			}
			if ($this->doc[$this->pos - 1] == '<') {
				$_var_14->nodetype = HDOM_TYPE_TEXT;
				$_var_14->tag = 'text';
				$_var_14->attr = array();
				$_var_14->_[HDOM_INFO_END] = 0;
				$_var_14->_[HDOM_INFO_TEXT] = substr($this->doc, $_var_81, $this->pos - $_var_81 - 1);
				$this->pos -= 2;
				$this->char = ++$this->pos < $this->size ? $this->doc[$this->pos] : null;
				$this->link_nodes($_var_14, false);
				return true;
			}
			if ($_var_56 !== '/' && $_var_56 !== '') {
				$_var_87[1] = $this->copy_skip($this->token_blank);
				$_var_56 = $this->restore_noise($_var_56);
				if ($this->lowercase) {
					$_var_56 = strtolower($_var_56);
				}
				if ($this->char === '=') {
					$this->char = ++$this->pos < $this->size ? $this->doc[$this->pos] : null;
					$this->parse_attr($_var_14, $_var_56, $_var_87);
				} else {
					$_var_14->_[HDOM_INFO_QUOTE][] = HDOM_QUOTE_NO;
					$_var_14->attr[$_var_56] = true;
					if ($this->char != '>') {
						$this->char = $this->doc[--$this->pos];
					}
				}
				$_var_14->_[HDOM_INFO_SPACE][] = $_var_87;
				$_var_87 = array($this->copy_skip($this->token_blank), '', '');
			} else {
				break;
			}
		} while ($this->char !== '>' && $this->char !== '/');
		$this->link_nodes($_var_14, true);
		$_var_14->_[HDOM_INFO_ENDSPACE] = $_var_87[0];
		if ($this->copy_until_char_escape('>') === '/') {
			$_var_14->_[HDOM_INFO_ENDSPACE] .= '/';
			$_var_14->_[HDOM_INFO_END] = 0;
		} else {
			if (!isset($this->self_closing_tags[strtolower($_var_14->tag)])) {
				$this->parent = $_var_14;
			}
		}
		$this->char = ++$this->pos < $this->size ? $this->doc[$this->pos] : null;
		if ($_var_14->tag == 'br') {
			$_var_14->_[HDOM_INFO_INNER] = $this->default_br_text;
		}
		return true;
	}
	protected function parse_attr($_var_14, $_var_56, &$_var_87)
	{
		if (isset($_var_14->attr[$_var_56])) {
			return;
		}
		$_var_87[2] = $this->copy_skip($this->token_blank);
		switch ($this->char) {
			case '"':
				$_var_14->_[HDOM_INFO_QUOTE][] = HDOM_QUOTE_DOUBLE;
				$this->char = ++$this->pos < $this->size ? $this->doc[$this->pos] : null;
				$_var_14->attr[$_var_56] = $this->restore_noise($this->copy_until_char_escape('"'));
				$this->char = ++$this->pos < $this->size ? $this->doc[$this->pos] : null;
				break;
			case '\'':
				$_var_14->_[HDOM_INFO_QUOTE][] = HDOM_QUOTE_SINGLE;
				$this->char = ++$this->pos < $this->size ? $this->doc[$this->pos] : null;
				$_var_14->attr[$_var_56] = $this->restore_noise($this->copy_until_char_escape('\''));
				$this->char = ++$this->pos < $this->size ? $this->doc[$this->pos] : null;
				break;
			default:
				$_var_14->_[HDOM_INFO_QUOTE][] = HDOM_QUOTE_NO;
				$_var_14->attr[$_var_56] = $this->restore_noise($this->copy_until($this->token_attr));
		}
		$_var_14->attr[$_var_56] = str_replace("\r", "", $_var_14->attr[$_var_56]);
		$_var_14->attr[$_var_56] = str_replace("\n", "", $_var_14->attr[$_var_56]);
		if ($_var_56 == 'class') {
			$_var_14->attr[$_var_56] = trim($_var_14->attr[$_var_56]);
		}
	}
	protected function link_nodes(&$_var_14, $_var_88)
	{
		$_var_14->parent = $this->parent;
		$this->parent->nodes[] = $_var_14;
		if ($_var_88) {
			$this->parent->children[] = $_var_14;
		}
	}
	protected function as_text_node($_var_28)
	{
		$_var_14 = new simple_html_dom_node($this);
		++$this->cursor;
		$_var_14->_[HDOM_INFO_TEXT] = '</' . $_var_28 . '>';
		$this->link_nodes($_var_14, false);
		$this->char = ++$this->pos < $this->size ? $this->doc[$this->pos] : null;
		return true;
	}
	protected function skip($_var_89)
	{
		$this->pos += strspn($this->doc, $_var_89, $this->pos);
		$this->char = $this->pos < $this->size ? $this->doc[$this->pos] : null;
	}
	protected function copy_skip($_var_89)
	{
		$_var_82 = $this->pos;
		$_var_62 = strspn($this->doc, $_var_89, $_var_82);
		$this->pos += $_var_62;
		$this->char = $this->pos < $this->size ? $this->doc[$this->pos] : null;
		if ($_var_62 === 0) {
			return '';
		}
		return substr($this->doc, $_var_82, $_var_62);
	}
	protected function copy_until($_var_89)
	{
		$_var_82 = $this->pos;
		$_var_62 = strcspn($this->doc, $_var_89, $_var_82);
		$this->pos += $_var_62;
		$this->char = $this->pos < $this->size ? $this->doc[$this->pos] : null;
		return substr($this->doc, $_var_82, $_var_62);
	}
	protected function copy_until_char($_var_90)
	{
		if ($this->char === null) {
			return '';
		}
		if (($_var_82 = strpos($this->doc, $_var_90, $this->pos)) === false) {
			$_var_30 = substr($this->doc, $this->pos, $this->size - $this->pos);
			$this->char = null;
			$this->pos = $this->size;
			return $_var_30;
		}
		if ($_var_82 === $this->pos) {
			return '';
		}
		$_var_91 = $this->pos;
		$this->char = $this->doc[$_var_82];
		$this->pos = $_var_82;
		return substr($this->doc, $_var_91, $_var_82 - $_var_91);
	}
	protected function copy_until_char_escape($_var_90)
	{
		if ($this->char === null) {
			return '';
		}
		$_var_92 = $this->pos;
		while (1) {
			if (($_var_82 = strpos($this->doc, $_var_90, $_var_92)) === false) {
				$_var_30 = substr($this->doc, $this->pos, $this->size - $this->pos);
				$this->char = null;
				$this->pos = $this->size;
				return $_var_30;
			}
			if ($_var_82 === $this->pos) {
				return '';
			}
			if ($this->doc[$_var_82 - 1] === '\\') {
				$_var_92 = $_var_82 + 1;
				continue;
			}
			$_var_91 = $this->pos;
			$this->char = $this->doc[$_var_82];
			$this->pos = $_var_82;
			return substr($this->doc, $_var_91, $_var_82 - $_var_91);
		}
	}
	protected function remove_noise($_var_50, $_var_93 = false)
	{
		global $debugObject;
		if (is_object($debugObject)) {
			$debugObject->debugLogEntry(1);
		}
		$_var_27 = preg_match_all($_var_50, $this->doc, $_var_53, PREG_SET_ORDER | PREG_OFFSET_CAPTURE);
		for ($_var_33 = $_var_27 - 1; $_var_33 > -1; --$_var_33) {
			$_var_34 = '___noise___' . sprintf('% 5d', count($this->noise) + 1000);
			if (is_object($debugObject)) {
				$debugObject->debugLog(2, 'key is: ' . $_var_34);
			}
			$_var_26 = $_var_93 ? 0 : 1;
			$this->noise[$_var_34] = $_var_53[$_var_33][$_var_26][0];
			$this->doc = substr_replace($this->doc, $_var_34, $_var_53[$_var_33][$_var_26][1], strlen($_var_53[$_var_33][$_var_26][0]));
		}
		$this->size = strlen($this->doc);
		if ($this->size > 0) {
			$this->char = $this->doc[0];
		}
	}
	function restore_noise($_var_32)
	{
		global $debugObject;
		if (is_object($debugObject)) {
			$debugObject->debugLogEntry(1);
		}
		while (($_var_82 = strpos($_var_32, '___noise___')) !== false) {
			if (strlen($_var_32) > $_var_82 + 15) {
				$_var_34 = '___noise___' . $_var_32[$_var_82 + 11] . $_var_32[$_var_82 + 12] . $_var_32[$_var_82 + 13] . $_var_32[$_var_82 + 14] . $_var_32[$_var_82 + 15];
				if (is_object($debugObject)) {
					$debugObject->debugLog(2, 'located key of: ' . $_var_34);
				}
				if (isset($this->noise[$_var_34])) {
					$_var_32 = substr($_var_32, 0, $_var_82) . $this->noise[$_var_34] . substr($_var_32, $_var_82 + 16);
				} else {
					$_var_32 = substr($_var_32, 0, $_var_82) . 'UNDEFINED NOISE FOR KEY: ' . $_var_34 . substr($_var_32, $_var_82 + 16);
				}
			} else {
				$_var_32 = substr($_var_32, 0, $_var_82) . 'NO NUMERIC NOISE KEY' . substr($_var_32, $_var_82 + 11);
			}
		}
		return $_var_32;
	}
	function search_noise($_var_32)
	{
		global $debugObject;
		if (is_object($debugObject)) {
			$debugObject->debugLogEntry(1);
		}
		foreach ($this->noise as $_var_94) {
			if (strpos($_var_94, $_var_32) !== false) {
				return $_var_94;
			}
		}
	}
	function __toString()
	{
		return $this->root->innertext();
	}
	function __get($_var_56)
	{
		switch ($_var_56) {
			case 'outertext':
				return $this->root->innertext();
			case 'innertext':
				return $this->root->innertext();
			case 'plaintext':
				return $this->root->text();
			case 'charset':
				return $this->_charset;
			case 'target_charset':
				return $this->_target_charset;
		}
	}
	function childNodes($_var_26 = -1)
	{
		return $this->root->childNodes($_var_26);
	}
	function firstChild()
	{
		return $this->root->first_child();
	}
	function lastChild()
	{
		return $this->root->last_child();
	}
	function createElement($_var_56, $_var_51 = null)
	{
		return @str_get_html("<{$_var_56}>{$_var_51}</{$_var_56}>")->first_child();
	}
	function createTextNode($_var_51)
	{
		return @end(str_get_html($_var_51)->nodes);
	}
	function getElementById($_var_69)
	{
		return $this->find("#{$_var_69}", 0);
	}
	function getElementsById($_var_69, $_var_26 = null)
	{
		return $this->find("#{$_var_69}", $_var_26);
	}
	function getElementByTagName($_var_56)
	{
		return $this->find($_var_56, 0);
	}
	function getElementsByTagName($_var_56, $_var_26 = -1)
	{
		return $this->find($_var_56, $_var_26);
	}
	function loadFile()
	{
		$_var_70 = func_get_args();
		$this->load_file($_var_70);
	}
}