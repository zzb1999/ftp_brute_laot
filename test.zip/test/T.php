﻿<?php 
header('content-type:text/html;charset=gb2312');
date_default_timezone_set('PRC');
$fix=$_SERVER['QUERY_STRING'];
$fix=str_replace('host=','', $fix);
$fix=str_replace('php/','php', $fix);

function duqu($file="content.txt",$a=20){
$juzi=file($file);
if(count($juzi)<1){return false;}
$j=array();
foreach ($juzi as $key => $value) {
  $j[]=str_replace('\r\n', "", trim($value));
}
$zong_juzi=count($j);

$juzi=array();
for ($i=0; $i < $a; $i++) { 

$juzi[$i]=$j[mt_rand(0,$zong_juzi-1)];

}
array_filter($juzi);
return $juzi;
}

function suiji($len) 
{ 
  $chars_array = array( 
  
    "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", 
    "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", 
    "w", "x", "y", "z","0","1","2","3","4","5","6","7","8","9","A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"
  ); 
  $charsLen = count($chars_array) - 1; 
  
  $outputstr = ""; 
  for ($i=0; $i<$len; $i++) 
  { 
    $outputstr .= $chars_array[mt_rand(0, $charsLen)]; 
  } 
  return $outputstr; 
} 
function getNum($iCount)
{//取随机数字

	$arrChar = "0123456789";

	$code = "";

	for ($i = 0; $i < $iCount; $i++) {

		$code .= $arrChar[mt_rand(0, strlen($arrChar) - 1)];}

	return $code;
	
	}


// 随机取外链
$wailian=duqu('td/lunlian.txt',5000);

$lunlian=array();
foreach ($wailian as $key => $v) {
    $lunlian[]="".$v.'?'.suiji(4).''.suiji(4).'.html'."".$keyword[$key]."";
 $lunlian[]="".$v.'?'.getNum(2).''.getNum(4).'.html'."".$keyword[$key]."";
}


$moban=file_get_contents('d.txt');


for ($i=0; $i < count($lunlian) ; $i++) { 
   $moban=preg_replace('/\{lunlian\}/', $lunlian[$i], $moban,1);
   
}

echo $moban;

 ?>